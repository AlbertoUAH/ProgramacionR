Nota: el fichero datos_provincias.csv contiene el numero de casos por cada provincia con la columna con el codigo de la Comunidad Autonoma correspondiente (como salida de la Pregunta 2 - Apartado a)

Por otro lado, el fichero level500.dat muestra un ejemplo del fichero de salida de la Pregunta 3 - Apartado e) (separado por espacios en blanco)